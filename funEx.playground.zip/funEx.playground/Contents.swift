import UIKit


    
// 3[a] extra mark



// fu

func toString(_ x :Any)->String {
    return "\(x)"
    
    
}
toString(4)




var  x = Int(toString(4))


//فكرة الكلوجر اقدر استخدمها ك نوع بيانات




// map filter- reduce for each
//r.forEach{item in  print item}
    

//var email = "hi@gmail.com"
//et x = array(email)
//for  i in x {
  //  var r=x.filter({"@"||"."})
   // continue
//    }






let arr:[Int] = [5,7,55,4,2,1]
let v = arr.filter{i in  arr
    i % 3   == 0 }


